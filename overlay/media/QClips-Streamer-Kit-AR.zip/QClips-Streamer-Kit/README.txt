﻿QClips - حزمة الستريمرز / Streamer kit
https://qclips.app

======================================================================
العربية
======================================================================

QClips برنامج مجاني لحفظ لقطات الألعاب على ويندوز. هذي الحزمة فيها إعلان متحرك
تحطه في بثك، وأنت تختار الشكل اللي يناسبك.

الأشكال التسعة
--------------
1) شريط سفلي (bar): إعلان كبير أسفل الشاشة فيه لقطة لعب والـQR كود. مرة كل 10-20 دقيقة.
2) بطاقة في الزاوية (card): نفس الفكرة في زاوية الشاشة.
3) شريط صغير (mini): مرتب تحت الكام، يطلع كل دقيقة إلى 5 دقائق.
4) شارة دائمة (badge): صغيرة وثابتة في الزاوية طول البث.
5) شريط أخبار (ticker): سطر رفيع أسفل الشاشة أو أعلاها والنص يمشي.
6) لوحة جانبية (side): لوحة طويلة تدخل من يمين الشاشة أو يسارها.
7) إشعار (notify): إشعار صغير ينبثق مثل إشعار QClips داخل اللعبة.
8) مربع QR (tile): مربع صغير فيه الـQR كود، دائم.
9) شاشة استراحة (scene): شاشة كاملة لوقت "راجع بعد شوي" أو "البث يبدأ بعد شوي".

الطريقة الأولى (الأفضل): رابط Browser Source
---------------------------------------------
يتحرك ويتكرر لحاله ويوصله أي تحديث تلقائياً.
1. في OBS: من Sources اضغط + واختر Browser.
   في Streamlabs: اضغط + واختر Browser Source.
2. الصق الرابط في خانة URL، واكتب المقاس اللي جنبه.
3. فعّل "Shutdown source when not visible" و"Refresh browser when scene becomes active".
4. اللي مقاسه 1920x1080 خلّه بكامل الشاشة فوق اللعبة. والصغار اسحبهم لأي مكان.

  شريط سفلي      1920x1080   https://qclips.app/overlay/?lang=ar
  بطاقة          1920x1080   https://qclips.app/overlay/?lang=ar&layout=card
  شريط صغير      600x188     https://qclips.app/overlay/?lang=ar&layout=mini&every=120
  شارة دائمة     420x136     https://qclips.app/overlay/?lang=ar&layout=badge
  شريط أخبار     1920x1080   https://qclips.app/overlay/?lang=ar&layout=ticker
  لوحة جانبية    1920x1080   https://qclips.app/overlay/?lang=ar&layout=side
  إشعار          560x124     https://qclips.app/overlay/?lang=ar&layout=notify&every=300
  مربع QR        300x372     https://qclips.app/overlay/?lang=ar&layout=tile
  شاشة استراحة   1920x1080   https://qclips.app/overlay/?lang=ar&layout=scene
                             (أو &title=soon لـ "البث يبدأ بعد شوي")

تبي تغيّر الشكل؟ صفحة الستريمرز تسوي لك الرابط وتعرض لك معاينة حية:
  - اللون: أزرق، بنفسجي، سماوي، أخضر، ذهبي، برتقالي، أحمر وردي، وردي
  - الطابع: داكن، فاتح، أو نيون مضيء
  - الزوايا: دائرية أو حادة
  - طريقة الدخول: انزلاق، قفزة، ظهور تدريجي، أو قلب
  - الحجم، وإظهار شاشة اللعب أو إخفاؤها، والمكان، وكل كم يطلع وكم يبقى
  https://qclips.app/ar/streamers

الطريقة الثانية: الملفات اللي في هذي الحزمة (مجلد Arabic)
-----------------------------------------------------------
فيديوهات شفافة (WebM): bar وcard وticker وside بمقاس 1920x1080،
وmini بمقاس 600x188، وnotify بمقاس 560x124.
صور شفافة (PNG): badge وtile، وscene صورة كاملة لشاشة الاستراحة.

في OBS أضف الفيديو كـ Media Source وشيل علامة Loop، وأظهره وقت ما تبي أو من
اختصار. والصورة أضفها كـ Image.

نصايح
-----
- الـQR كود ينمسح من الجوال من بث 720p وفوق (الشارة أفضل لها 1080p).
- خلّه بعيد عن الكام والشات والتنبيهات.
- شاشة الاستراحة حطها في مشهد لحالها وانتقل له لما تقوم من البث.
- اذكره في البث بين فترة وفترة: "الرابط qclips.app".


======================================================================
English
======================================================================

QClips is free game clipping for Windows. This kit is an animated ad for your
stream; pick the style that suits you.

The nine styles
---------------
1) Bar: a lower third with gameplay and a QR code. Once every 10-20 minutes.
2) Card: the same idea in a corner of the screen.
3) Mini: a small strip for under your webcam; every 1 to 5 minutes.
4) Badge: small, always on, in a corner.
5) News ticker: a thin line along the bottom or top with scrolling text.
6) Side panel: a tall panel that slides in from the left or right edge.
7) Notification: a small pop-up like the one QClips shows in game.
8) QR tile: a small square with the QR code, always on.
9) Break screen: a full screen for "Be right back" or "Starting soon".

Option 1 (best): a browser source link
--------------------------------------
It animates and repeats by itself and always has the latest version.
1. OBS: Sources, +, Browser. Streamlabs: +, Browser Source.
2. Paste the link as the URL and set the size next to it.
3. Tick "Shutdown source when not visible" and "Refresh browser when scene
   becomes active".
4. 1920x1080 ones go full screen above your game; drag the small ones anywhere.

  Bar            1920x1080   https://qclips.app/overlay/?lang=en
  Card           1920x1080   https://qclips.app/overlay/?lang=en&layout=card
  Mini           600x188     https://qclips.app/overlay/?lang=en&layout=mini&every=120
  Badge          420x136     https://qclips.app/overlay/?lang=en&layout=badge
  News ticker    1920x1080   https://qclips.app/overlay/?lang=en&layout=ticker
  Side panel     1920x1080   https://qclips.app/overlay/?lang=en&layout=side
  Notification   560x124     https://qclips.app/overlay/?lang=en&layout=notify&every=300
  QR tile        300x372     https://qclips.app/overlay/?lang=en&layout=tile
  Break screen   1920x1080   https://qclips.app/overlay/?lang=en&layout=scene
                             (or &title=soon for "Starting soon")

Want a different look? Build your own link, with a live preview, on the
streamers page:
  - colour: blue, violet, cyan, green, amber, orange, rose or pink
  - theme: dark, light or neon glow
  - corners: rounded or sharp
  - entrance: slide, pop, fade or flip
  - size, the gameplay screen shown or hidden, position, how often it shows
    up and how long it stays
  https://qclips.app/streamers

Option 2: the files in this kit (English folder)
------------------------------------------------
Transparent videos (WebM): bar, card, ticker and side at 1920x1080,
mini at 600x188 and notify at 560x124.
Transparent pictures (PNG): badge and tile, and scene, a full break screen.

In OBS add a video as a Media Source, untick Loop, and show it when you like
or from a hotkey. Add a picture as an Image source.

Tips
----
- The QR code scans from a phone at 720p and above (the badge's is best at 1080p).
- Keep it clear of your webcam, chat and alerts.
- Put the break screen in a scene of its own and switch to it when you step away.
- Mention it on stream once in a while: "qclips.app".

The gameplay in the videos is VALORANT, recorded with QClips. VALORANT belongs to
Riot Games; QClips isn't affiliated with or endorsed by them.
