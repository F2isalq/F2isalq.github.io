﻿QClips - حزمة الستريمرز / Streamer kit
https://qclips.app

======================================================================
العربية
======================================================================

QClips برنامج مجاني لحفظ لقطات الألعاب على ويندوز. هذي الحزمة فيها إعلان متحرك
تحطه في بثك، وأنت تختار الشكل اللي يناسبك.

الأشكال الأربعة
---------------
1) شريط سفلي (bar): إعلان كبير أسفل الشاشة فيه لقطة من البرنامج والـQR كود.
   يناسب مرة كل 10 إلى 20 دقيقة.
2) بطاقة في الزاوية (card): نفس الفكرة لكن في زاوية الشاشة.
3) شريط صغير (mini): صغير ومرتب تحت الكام، ويقدر يطلع كل دقيقة إلى 5 دقائق.
4) شارة دائمة (badge): صغيرة وثابتة في الزاوية طول البث، ما تزعج.

الطريقة الأولى (الأفضل): رابط Browser Source
---------------------------------------------
يتحرك ويتكرر لحاله ويوصله أي تحديث تلقائياً.
1. في OBS: من Sources اضغط + واختر Browser.
   في Streamlabs: اضغط + واختر Browser Source.
2. الصق الرابط في خانة URL، واكتب المقاس اللي جنبه.
3. فعّل "Shutdown source when not visible" و"Refresh browser when scene becomes active".
4. للشريط والبطاقة: خلّه فوق اللعبة بكامل الشاشة. للشريط الصغير والشارة: اسحبه لأي مكان.

  شريط سفلي عربي     1920x1080   https://qclips.app/overlay/?lang=ar
  بطاقة عربية        1920x1080   https://qclips.app/overlay/?lang=ar&layout=card
  شريط صغير عربي     600x188     https://qclips.app/overlay/?lang=ar&layout=mini&every=120
  شارة دائمة عربية   420x136     https://qclips.app/overlay/?lang=ar&layout=badge

تبي تغيّر المكان أو كل كم يطلع أو كم يبقى؟ صفحة الستريمرز تسوي لك الرابط:
  https://qclips.app/ar/streamers.html

الطريقة الثانية: الملفات اللي في هذي الحزمة (مجلد Arabic)
-----------------------------------------------------------
  qclips-ar-bar.webm    فيديو شفاف 1920x1080 (حوالي 14 ثانية)
  qclips-ar-card.webm   فيديو شفاف 1920x1080 (حوالي 14 ثانية)
  qclips-ar-mini.webm   فيديو شفاف 600x188 (حوالي 12 ثانية)
  qclips-ar-badge.png   صورة شفافة 420x136 (ثابتة)

في OBS أضف الفيديو كـ Media Source وشيل علامة Loop، وأظهره وقت ما تبي أو من
اختصار. والصورة أضفها كـ Image.

نصايح
-----
- الـQR كود ينمسح من الجوال من بث 720p وفوق (الشارة أفضل لها 1080p).
- خلّه بعيد عن الكام والشات والتنبيهات.
- اذكره في البث بين فترة وفترة: "الرابط qclips.app".


======================================================================
English
======================================================================

QClips is free game clipping for Windows. This kit is an animated ad for your
stream; pick the style that suits you.

The four styles
---------------
1) Bar: a lower third with a look at the app and a QR code.
   Once every 10 to 20 minutes is plenty.
2) Card: the same idea in a corner of the screen.
3) Mini: a small strip for under your webcam; it can come every 1 to 5 minutes.
4) Badge: small, always on, in a corner. It stays out of the way.

Option 1 (best): a browser source link
--------------------------------------
It animates and repeats by itself and always has the latest version.
1. OBS: Sources, +, Browser. Streamlabs: +, Browser Source.
2. Paste the link as the URL and set the size next to it.
3. Tick "Shutdown source when not visible" and "Refresh browser when scene
   becomes active".
4. Bar and card: full screen, above your game. Mini and badge: drag them
   anywhere.

  Bar     1920x1080   https://qclips.app/overlay/?lang=en
  Card    1920x1080   https://qclips.app/overlay/?lang=en&layout=card
  Mini    600x188     https://qclips.app/overlay/?lang=en&layout=mini&every=120
  Badge   420x136     https://qclips.app/overlay/?lang=en&layout=badge

To change the position, how often it shows up or how long it stays, build your
own link on the streamers page:
  https://qclips.app/streamers.html

Option 2: the files in this kit (English folder)
------------------------------------------------
  qclips-en-bar.webm    transparent video, 1920x1080 (about 14 s)
  qclips-en-card.webm   transparent video, 1920x1080 (about 14 s)
  qclips-en-mini.webm   transparent video, 600x188 (about 12 s)
  qclips-en-badge.png   transparent picture, 420x136 (still)

In OBS add a video as a Media Source, untick Loop, and show it when you like
or from a hotkey. Add the picture as an Image source.

Tips
----
- The QR code scans from a phone at 720p and above (the badge's is best at 1080p).
- Keep it clear of your webcam, chat and alerts.
- Mention it on stream once in a while: "qclips.app".

The gameplay in the videos is VALORANT, recorded with QClips. VALORANT belongs to
Riot Games; QClips isn't affiliated with or endorsed by them.
